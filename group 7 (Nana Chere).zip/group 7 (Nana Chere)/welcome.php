
<!--<!DOCTYPE html>
<html>
<head>

	<title>Welcome</title>
	<link rel="stylesheet" href="style.css" />

</head>
<body>

<div id="Topman">
<center><h1 id="PU"> Project One </h1></center>
</div>

<ul>
  	     	<li><a href="signup.php">Sign Up</a></li>
  	     	<li><a href="welcpage.php">Login</a></li>
  	     	<li><a href="showretrieve.php"> View All</a></li>

 </ul>


</form>


</body>
</html>-->
<!DOCTYPE html>
<html>

<head>

	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Registration Page</title>

	<link rel="stylesheet" href="css/demo.css">

</head>
	

	<header>
		<h1>Welcome</h1>
        <a href="welcpage.php" >login</a>
    </header>

    <ul>
        <li><a href="welcome.php" class="hover">Home</a></li>
        <li><a href="signup.php" class="hover">Register</a></li>
         <li><a href="viewaccount.php" class="hover">view</a></li>

      
    </ul>


   
    </div>


</body>

</html>


