<?php
include('config1.php'); 
include ('retrieve.php'); ?> 


<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Show all</title>
</head>

<body>
<?php echo $output; ?> 
</body>
</html>
