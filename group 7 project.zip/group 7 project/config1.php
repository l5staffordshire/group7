<?php
$host='localhost';
$user='root';
$password='';
$database = 'project1';
$connect_db = mysqli_connect('localhost','root', '' , 'project1');
?>